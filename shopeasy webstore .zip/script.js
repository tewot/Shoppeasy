// user-admin-updated.js
// Based on your original code — minimal changes added:
//  - persist mode in localStorage under key 'se_user_mode'
//  - dispatch 'adminModeChanged' event when mode changes
//  - listen for storage changes (cross-tab sync)

(async () => {
  // Password hash (admin123)
  const ADMIN_HASH = "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9";
  const MODE_KEY = 'se_user_mode';
  
  let mode = "guest"; // guest | customer | admin
  let currentRating = 0;
  
  // DOM elements (assume these IDs exist as in your HTML)
  const userIcon = document.getElementById("userIcon");
  const modeMenu = document.getElementById("modeMenu");
  const customerBtn = document.getElementById("customerModeBtn");
  const adminBtn = document.getElementById("adminModeBtn");
  const logoutBtn = document.getElementById("logoutBtn");
  const reviewForm = document.getElementById("reviewForm");
  const reviewsList = document.getElementById("reviewsList");
  
  // safe: star rating container may or may not exist
  const starSpans = document.querySelectorAll("#starRating span");
  
  // Show/hide menu
  if (userIcon && modeMenu) {
    userIcon.addEventListener("click", () => {
      modeMenu.classList.toggle("hidden");
    });
  }
  
  // Star rating
  starSpans.forEach(star => {
    star.addEventListener("click", () => {
      currentRating = parseInt(star.dataset.value);
      document.querySelectorAll("#starRating span").forEach(s => {
        s.classList.toggle("active", parseInt(s.dataset.value) <= currentRating);
      });
    });
  });
  
  // SHA-256 function
  async function sha256(message) {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
  }
  
  // ---------- applyMode: central UI + persistence + event ----------
  function persistMode(m) {
    if (m && m !== 'guest') localStorage.setItem(MODE_KEY, m);
    else localStorage.removeItem(MODE_KEY);
  }
  
  function applyMode(newMode) {
    mode = newMode || 'guest';
    // persist for other pages/tabs
    persistMode(mode);
    
    // update UI (your existing look/behavior)
    if (userIcon) {
      userIcon.className = "fas fa-user"; // reset
      if (mode === 'guest') userIcon.classList.add('mode-guest');
      if (mode === 'customer') userIcon.classList.add('mode-customer');
      if (mode === 'admin') userIcon.classList.add('mode-admin');
    }
    if (reviewForm) {
      if (mode === 'guest') reviewForm.classList.add('hidden');
      else reviewForm.classList.remove('hidden');
    }
    if (logoutBtn) {
      if (mode === 'admin') logoutBtn.classList.remove('hidden');
      else logoutBtn.classList.add('hidden');
    }
    if (modeMenu) modeMenu.classList.add('hidden');
    
    // notify other in-page listeners (e.g., product page listeners)
    document.dispatchEvent(new CustomEvent('adminModeChanged', { detail: { mode } }));
    
    // refresh reviews UI using your function (safe call)
    try { loadReviews(); } catch (e) { /* ignore if not in scope */ }
  }
  
  // Initialize mode from storage (persisted session)
  (function initMode() {
    const stored = localStorage.getItem(MODE_KEY);
    if (stored === 'admin' || stored === 'customer') mode = stored;
    else mode = 'guest';
    // apply initial UI
    applyMode(mode);
  })();
  
  // Load reviews (keeps your behavior but uses updated `mode`)
  function loadReviews() {
    if (!reviewsList) return;
    reviewsList.innerHTML = "";
    const reviews = JSON.parse(localStorage.getItem("reviews") || "[]");
    
    reviews.forEach((rev, index) => {
      const div = document.createElement("div");
      div.classList.add("review");
      div.innerHTML = `
        <div class="rating">${"★".repeat(rev.rating)}${"☆".repeat(5 - rev.rating)}</div>
        <p>"${rev.text}"</p>
        <h4>- ${rev.name}</h4>
      `;
      
      if (mode === "admin") {
        const btn = document.createElement("button");
        btn.classList.add("delete-btn");
        btn.innerHTML = "&times;";
        btn.onclick = () => {
          const r = JSON.parse(localStorage.getItem("reviews") || "[]");
          r.splice(index, 1);
          localStorage.setItem("reviews", JSON.stringify(r));
          loadReviews();
        };
        div.appendChild(btn);
      }
      
      reviewsList.appendChild(div);
    });
  }
  
  // Add review (safe)
  const submitBtn = document.getElementById("submitReview");
  if (submitBtn) {
    submitBtn.addEventListener("click", () => {
      const nameNode = document.getElementById("reviewName");
      const textNode = document.getElementById("reviewText");
      const name = nameNode ? nameNode.value.trim() : '';
      const text = textNode ? textNode.value.trim() : '';
      if (!name || !text || currentRating === 0) return alert("Please fill all fields and give rating!");
      
      const reviews = JSON.parse(localStorage.getItem("reviews") || "[]");
      reviews.push({ name, text, rating: currentRating });
      localStorage.setItem("reviews", JSON.stringify(reviews));
      
      if (nameNode) nameNode.value = "";
      if (textNode) textNode.value = "";
      currentRating = 0;
      document.querySelectorAll("#starRating span").forEach(s => s.classList.remove("active"));
      
      loadReviews();
    });
  }
  
  // Mode change buttons
  if (customerBtn) {
    customerBtn.addEventListener("click", () => {
      applyMode('customer');
    });
  }
  
  if (adminBtn) {
    adminBtn.addEventListener("click", async () => {
      const pass = prompt("Enter Admin Password:");
      if (!pass) return;
      const passHash = await sha256(pass);
      if (passHash === ADMIN_HASH) {
        applyMode('admin');
      } else {
        alert("Wrong password!");
      }
    });
  }
  
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      applyMode('guest');
    });
  }
  
  // Cross-tab sync: listen for changes to se_user_mode and reviews
  window.addEventListener('storage', (e) => {
    if (e.key === MODE_KEY) {
      const newMode = e.newValue || 'guest';
      applyMode(newMode);
    }
    if (e.key === 'reviews') {
      // reviews changed in other tab
      try { loadReviews(); } catch (ex) {}
    }
  });
  
  // Initial render of reviews (if relevant)
  try { loadReviews(); } catch (e) {}
  
})();

// product-admin-listener.js
(function(){
  const MODE_KEY = 'se_user_mode';
  const adminBlock = document.getElementById('pdAdminBlock');
  const detailsBlock = document.getElementById('pdDetails');

  if (!adminBlock) return; // nothing to do if product page doesn't have admin block

  // set initial visibility from localStorage
  const initMode = localStorage.getItem(MODE_KEY) || 'guest';
  if (initMode === 'admin') {
    adminBlock.removeAttribute('hidden');
    if (detailsBlock) detailsBlock.removeAttribute('hidden'); // optional: show details for admin
  } else {
    adminBlock.setAttribute('hidden','');
  }

  // listen for in-page custom event
  document.addEventListener('adminModeChanged', (ev) => {
    const m = (ev && ev.detail && ev.detail.mode) || localStorage.getItem(MODE_KEY) || 'guest';
    if (m === 'admin') {
      adminBlock.removeAttribute('hidden');
      if (detailsBlock) detailsBlock.removeAttribute('hidden');
    } else {
      adminBlock.setAttribute('hidden','');
    }
  });

  // listen for storage event (cross-tab)
  window.addEventListener('storage', (e) => {
    if (e.key === MODE_KEY) {
      const newMode = e.newValue || 'guest';
      if (newMode === 'admin') {
        adminBlock.removeAttribute('hidden');
        if (detailsBlock) detailsBlock.removeAttribute('hidden');
      } else {
        adminBlock.setAttribute('hidden','');
      }
    }
  });
})();

// menu toggle + hamburger animation
const menuBtn = document.getElementById("menu-btn");
const navLinks = document.getElementById("nav-links");

if (menuBtn && navLinks) {
  menuBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    navLinks.classList.toggle("show");
    menuBtn.classList.toggle("active");
  });

  // close menu when clicking outside (mobile)
  document.addEventListener("click", (e) => {
    if (!navLinks.contains(e.target) && !menuBtn.contains(e.target)) {
      navLinks.classList.remove("show");
      menuBtn.classList.remove("active");
    }
  });

  // smooth scroll for links & close mobile menu after click
  navLinks.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", (ev) => {
      ev.preventDefault();
      const href = link.getAttribute("href");
      if (!href || !href.startsWith("#")) return;
      const id = href.slice(1);
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
      navLinks.classList.remove("show");
      menuBtn.classList.remove("active");
    });
  });
}
// ===== Hero Slider Auto Change =====
const slides = document.querySelectorAll(".hero-slider .slide");
let currentSlide = 0;

function changeSlide() {
  slides[currentSlide].classList.remove("active");
  currentSlide = (currentSlide + 1) % slides.length;
  slides[currentSlide].classList.add("active");
}

// change every 3 seconds
setInterval(changeSlide, 3000);

// ===== Smooth Scroll for Nav Links =====
document.querySelectorAll("nav a").forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault(); // default jump रोकना
    const targetId = link.getAttribute("href").substring(1); 
    const targetEl = document.getElementById(targetId);
    if (targetEl) {
      targetEl.scrollIntoView({ behavior: "smooth" });
    }
    navLinks.classList.remove("show"); // mobile menu बंद करना
  });
});

// product detail toggle
const pdToggleBtn = document.getElementById("pdToggleDetails");
const pdDetails = document.getElementById("pdDetails");

if (pdToggleBtn && pdDetails) {
  pdToggleBtn.addEventListener("click", () => {
    const isHidden = pdDetails.hasAttribute("hidden");

    if (isHidden) {
      pdDetails.removeAttribute("hidden");
      pdToggleBtn.textContent = "Hide Details";
    } else {
      pdDetails.setAttribute("hidden", "");
      pdToggleBtn.textContent = "More Details";
    }
  });
}
