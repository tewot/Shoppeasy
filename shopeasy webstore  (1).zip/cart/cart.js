/* cart.js - complete prototype
   Admin password: admin123
   Free shipping threshold: > 500
   GST: 5%
   Express fee: +60
*/

(() => {
  /* ---------------- Config ---------------- */
  const KEY_CART = 'se_cart_v3';
  const WHATSAPP_NUMBER = '919315021828'; // <- change to your number if needed
  const FREE_SHIPPING_THRESHOLD = 500;
  const BASE_SHIPPING = 49; // charged when subtotal <= threshold
  const EXPRESS_FEE = 60;
  const GST_RATE = 0.05;
  const ADMIN_NAME = 'aman.owner.admin';
  const ADMIN_PASS = 'admin123'; // demo password (replace & secure server-side for production)

  /* ---------------- State ----------------- */
  let DEMO_PRODUCTS = [
    { id: 'p1', name: 'Smart Watch', price: 2999, img: 'images/image 1.jpg', variant: 'Black', stock: 4, sku:'SW-BLK-42', hsn:'8517', mrp:3999, cost:2050, long:'1.69" HD, 7-day battery, HR & SpO₂', bullets: ['1.69\" HD display','7-day battery','Heart-rate & SpO₂ tracking','IP68 water resistant'] },
    { id: 'p2', name: 'Wireless Earbuds', price: 1599, img: 'images/image 2.jpg', variant: 'White', stock: 12, sku:'EB-WL-01', hsn:'8518', mrp:1999, cost:700, long:'True wireless stereo, charging case, up to 20h', bullets: ['TWS','Charging case','20h playback'] },
    { id: 'p3', name: 'Trendy Jacket', price: 3999, img: 'images/image 3.jpg', variant: 'M', stock: 6, sku:'JK-TR-01', hsn:'6203', mrp:4999, cost:1800, long:'Polyester, water resistant lining, stylish fit', bullets: ['Water-resistant','Modern fit','Multiple pockets'] },
    { id: 'p4', name: 'Classic Sneakers', price: 2599, img: 'images/image 4.jpg', variant: '9', stock: 3, sku:'SN-CLS-09', hsn:'6404', mrp:3499, cost:1200, long:'Comfort sole, breathable knit, rubber outsole', bullets: ['Comfort sole','Breathable','Durable outsole'] }
    ,{id: 'p4', name: 'Classic Sneakers', price: 2599, img: 'images/image 5.png', variant: '9', stock: 3, sku:'SN-CLS-09', hsn:'6404', mrp:3499, cost:1200, long:'Comfort sole, breathable knit, rubber outsole', bullets: ['Comfort sole','Breathable','Durable outsole'],}
    ,{id: 'p4', name: 'Classic Sneakers', price: 2599, img: 'images/image 6.jpg', variant: '9', stock: 3, sku:'SN-CLS-09', hsn:'6404', mrp:3499, cost:1200, long:'Comfort sole, breathable knit, rubber outsole', bullets: ['Comfort sole','Breathable','Durable outsole'] }
    ,{id: 'p4', name: 'Classic Sneakers', price: 2599, img: 'images/image 7.png', variant: '9', stock: 3, sku:'SN-CLS-09', hsn:'6404', mrp:3499, cost:1200, long:'Comfort sole, breathable knit, rubber outsole',  bullets: ['Comfort sole','Breathable','Durable outsole'] }
    ,{id: 'p4', name: 'Classic Sneakers', price: 2599, img: 'images/image 8.png', variant: '9', stock: 3, sku:'SN-CLS-09', hsn:'6404', mrp:3499, cost:1200, long:'Comfort sole, breathable knit, rubber outsole', bullets: ['Comfort sole','Breathable','Durable outsole'] }
  ];

  let cart = loadCart();               // array of {id,name,price,img,qty}
  let adminMode = false;
  let currentUser = null;
  let currentProduct = null;

  /* --------------- DOM refs -------------- */
  const productsGrid = document.getElementById('productsGrid');
  const searchInput = document.getElementById('searchInput');
  const cartBtn = document.getElementById('cartBtn');
  const cartCountNode = document.getElementById('cartCount');
  const cartDrawer = document.getElementById('cartDrawer');
  const closeCartBtn = document.getElementById('closeCart');
  const cartItemsNode = document.getElementById('cartItems');
  const cartSubtotalNode = document.getElementById('cartSubtotal');
  const freeShipNote = document.getElementById('freeShipNote');
  const checkoutBtn = document.getElementById('checkoutBtn');
  const clearBtn = document.getElementById('clearBtn');
  const checkoutModal = document.getElementById('checkoutModal');
  const closeModal = document.getElementById('closeModal');
  const checkoutForm = document.getElementById('checkoutForm');
  const sendEmailBtn = document.getElementById('sendEmail');
  const toastNode = document.getElementById('toast');

  // product-detail refs
  const pdSection = document.getElementById('product-detail');
  const pdTitle = document.getElementById('pdTitle');
  const pdPrice = document.getElementById('pdPrice');
  const pdStock = document.getElementById('pdStock');
  const pdMainImg = document.getElementById('pdMainImg');
  const pdThumbs = document.getElementById('pdThumbs');
  const pdBullets = document.getElementById('pdBullets');
  const pdDetails = document.getElementById('pdDetails');
  const pdLong = document.getElementById('pdLong');
  const pdAdminBlock = document.getElementById('pdAdminBlock');
  const pdAddToCart = document.getElementById('pdAddToCart');
  const pdBack = document.getElementById('pdBack');
  const pdEdit = document.getElementById('pdEdit');
  const pdDelete = document.getElementById('pdDelete');

  // header/user refs
  const userIcon = document.getElementById('userIcon');
  const userModal = document.getElementById('userModal');
  const userNameInput = document.getElementById('userName');
  const userPasswordInput = document.getElementById('userPassword');
  const loginBtn = document.getElementById('loginBtn');
  const closeUserModal = document.getElementById('closeUserModal');
  const modalTitle = document.getElementById('modalTitle');
  const themeToggle = document.getElementById('themeToggle');
  
  
  /* --------------- Utilities ------------- */
  function saveCart(){ localStorage.setItem(KEY_CART, JSON.stringify(cart)); updateCartCount(); }
  function loadCart(){
    try {
      const raw = localStorage.getItem(KEY_CART);
      return raw ? JSON.parse(raw) : [];
    } catch(e){ return []; }
  }
  function money(n){ return '₹' + Number(n).toLocaleString('en-IN'); }
  function toast(msg, ms = 1500){
    if (!toastNode) return;
    toastNode.textContent = msg;
    toastNode.classList.add('show');
    setTimeout(()=> toastNode.classList.remove('show'), ms);
  }
  function generateId(){ return 'p' + Math.random().toString(36).slice(2,9); }
  function findProduct(id){ return DEMO_PRODUCTS.find(p => p.id === id); }
  function findCartItem(id){ return cart.find(i => i.id === id); }
  function updateCartCount(){ if (!cartCountNode) return; cartCountNode.textContent = cart.reduce((s,i)=> s + (i.qty||0), 0); }

  /* ---------- Render products grid ---------- */
  function renderDemoProducts(list = DEMO_PRODUCTS){
    if (!productsGrid) return;
    productsGrid.innerHTML = '';

    list.forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      card.dataset.id = p.id;
      card.innerHTML = `
        <div class="product-thumb"><img src="${p.img}" alt="${escapeHtml(p.name)}" loading="lazy"></div>
        <div class="product-title">${escapeHtml(p.name)}</div>
        <div class="small muted">${escapeHtml(p.variant)}</div>
        <div class="product-row">
          <div class="price strong">${money(p.price)}</div>
          <div style="display:flex;gap:8px">
            <button class="btn outline btn-view" data-id="${p.id}">view</button>
            <button class="btn primary btn-add" data-id="${p.id}">Add to cart</button>
          </div>
        </div>
      `;
      productsGrid.appendChild(card);

      // if adminMode add admin controls inline
      if (adminMode){
        const adminWrap = document.createElement('div');
        adminWrap.className = 'admin-controls';
        adminWrap.innerHTML = `
          <button class="btn soft btn-edit" data-id="${p.id}">✏️ Edit</button>
          <button class="btn soft btn-delete" data-id="${p.id}">🗑️ Delete</button>
        `;
        card.appendChild(adminWrap);
      }
    });
  }
  
  /* -------------- Product interactions -------------- */
  if (productsGrid){
    productsGrid.addEventListener('click', (e) => {
      const target = e.target;
      if (target.classList.contains('btn-view')){
        const id = target.dataset.id;
        const p = findProduct(id);
        if (p) showProductDetail(p);
      }
      if (target.classList.contains('btn-add')){
        const id = target.dataset.id;
        const p = findProduct(id);
        if (p) addToCart(p,1);
      }
      if (target.classList.contains('btn-edit') && adminMode){
        const id = target.dataset.id;
        const p = findProduct(id);
        if (p) openProductForm('edit', p);
      }
      if (target.classList.contains('btn-delete') && adminMode){
        const id = target.dataset.id;
        if (confirm('Delete this product?')) deleteProductById(id);
      }
    });
  }

  /* ------------- Product Detail view -------------- */
  function showProductDetail(p){
    currentProduct = p;
    if (!pdSection) return;
    pdSection.classList.remove('hidden');
    document.getElementById('products').classList.add('hidden');

    pdTitle.textContent = p.name;
    pdPrice.textContent = money(p.price);
    pdStock.textContent = p.stock > 0 ? `In stock (${p.stock})` : 'Out of stock';
    pdMainImg.src = p.images && p.images.length ? p.images[0] : p.img;

    pdThumbs.innerHTML = (p.images || []).map(src => `<img src="${src}" data-src="${src}" alt="">`).join('');
    pdBullets.innerHTML = (p.bullets || []).map(b => `<li>${escapeHtml(b)}</li>`).join('');
    pdLong.textContent = p.long || '';

    // admin data
    if (adminMode){
      pdAdminBlock.hidden = false;
      document.getElementById('pdSku') && (document.getElementById('pdSku').textContent = p.sku || '-');
      document.getElementById('pdMrp') && (document.getElementById('pdMrp').textContent = p.mrp ? money(p.mrp) : '-');
      document.getElementById('pdCost') && (document.getElementById('pdCost').textContent = p.cost ? money(p.cost) : '-');
      pdEdit.classList.remove('hidden');
      pdDelete.classList.remove('hidden');
    } else {
      pdAdminBlock.hidden = true;
      pdEdit.classList.add('hidden');
      pdDelete.classList.add('hidden');
    }
  }

  if (pdBack) pdBack.addEventListener('click', () => {
    pdSection.classList.add('hidden');
    document.getElementById('products').classList.remove('hidden');
  });

  if (pdThumbs){
    pdThumbs.addEventListener('click', (e) => {
      const t = e.target;
      if (t && t.dataset && t.dataset.src) pdMainImg.src = t.dataset.src;
    });
  }

  // Detail Add to Cart
  if (pdAddToCart) pdAddToCart.addEventListener('click', () => {
    if (currentProduct) addToCart(currentProduct,1);
  });

  // Detail Edit/Delete
  if (pdEdit) pdEdit.addEventListener('click', () => {
    if (currentProduct && adminMode) openProductForm('edit', currentProduct);
  });
  if (pdDelete) pdDelete.addEventListener('click', () => {
    if (currentProduct && adminMode && confirm('Delete product?')) {
      deleteProductById(currentProduct.id);
      pdBack.click();
    }
  });
  /* ---------------- Cart logic ---------------- */
  function addToCart(product, qty = 1){
    const item = findCartItem(product.id);
    if (item) item.qty = (item.qty || 0) + qty;
    else cart.push({ id: product.id, name: product.name, price: product.price, img: product.img, variant: product.variant, qty: qty });
    saveCart();
    renderCart();
    toast(`${product.name} added to cart`);
  }

  function deleteProductById(id){
    const idx = DEMO_PRODUCTS.findIndex(p => p.id === id);
    if (idx === -1) return;
    DEMO_PRODUCTS.splice(idx,1);
    // remove from cart if present
    cart = cart.filter(ci => ci.id !== id);
    saveCart();
    renderDemoProducts();
    renderCart();
    toast('Product deleted');
  }

  function renderCart(){
    if (!cartItemsNode) return;
    cartItemsNode.innerHTML = '';
    if (!cart.length) {
      cartItemsNode.innerHTML = `<div class="small muted" style="padding:12px">Your cart is empty. Add products to continue.</div>`;
    }
    let subtotal = 0;
    cart.forEach(it => {
      subtotal += it.price * it.qty;
      const node = document.createElement('div');
      node.className = 'cart-item';
      node.dataset.id = it.id;
      node.innerHTML = `
        <div class="cart-thumb"><img src="${it.img}" alt="${escapeHtml(it.name)}" loading="lazy"></div>
        <div class="cart-info">
          <div class="title">${escapeHtml(it.name)}</div>
          <div class="meta small">${escapeHtml(it.variant || '')}</div>
          <div class="meta small">Price: ${money(it.price)}</div>
        </div>
        <div class="qty-wrap">
          <div class="qty-controls" data-id="${it.id}">
            <button class="qty-decr" title="Decrease">−</button>
            <span class="qty-value">${it.qty}</span>
            <button class="qty-incr" title="Increase">+</button>
          </div>
          <button class="remove-btn" data-id="${it.id}">Remove</button>
        </div>
      `;
      cartItemsNode.appendChild(node);
    });

    cartSubtotalNode.textContent = money(subtotal);
    // shipping
    const shipping = subtotal > FREE_SHIPPING_THRESHOLD ? 0 : BASE_SHIPPING;
    if (subtotal > FREE_SHIPPING_THRESHOLD) freeShipNote.textContent = `🎉 Free shipping unlocked (subtotal > ${money(FREE_SHIPPING_THRESHOLD)})`;
    else freeShipNote.textContent = `Add ${money(Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal))} more for free shipping`;

    checkoutBtn.disabled = cart.length === 0;
    // disable open if empty
    if (cart.length === 0 && cartBtn) {
      cartBtn.setAttribute('aria-disabled','true');
      cartBtn.classList.add('disabled');
    } else if (cartBtn) {
      cartBtn.removeAttribute('aria-disabled');
      cartBtn.classList.remove('disabled');
    }
    updateCartCount();
  }

  // Delegated cart controls
  document.addEventListener('click', (e) => {
    const decr = e.target.closest('.qty-decr');
    const incr = e.target.closest('.qty-incr');
    const remove = e.target.closest('.remove-btn');
    if (decr){
      const id = decr.parentElement.dataset.id;
      changeQty(id, -1);
    } else if (incr){
      const id = incr.parentElement.dataset.id;
      changeQty(id, +1);
    } else if (remove){
      removeFromCart(remove.dataset.id);
    }
  });

  function changeQty(id, delta){
    const it = findCartItem(id);
    if (!it) return;
    it.qty = Math.max(1, (it.qty||0) + delta);
    saveCart();
    renderCart();
  }
  function removeFromCart(id){
    cart = cart.filter(i => i.id !== id);
    saveCart();
    renderCart();
    toast('Removed');
  }
  function clearCart(){
    cart = [];
    saveCart();
    renderCart();
    toast('Cart cleared');
  }

  /* ---------- Drawer & checkout events ---------- */
  if (cartBtn) cartBtn.addEventListener('click', () => {
    if (!cart.length){ toast('Your cart is empty. Add items first.'); return; }
    if (cartDrawer) { cartDrawer.classList.add('open'); cartDrawer.setAttribute('aria-hidden','false'); }
  });
  if (closeCartBtn) closeCartBtn.addEventListener('click', () => {
    if (cartDrawer) { cartDrawer.classList.remove('open'); cartDrawer.setAttribute('aria-hidden','true'); }
  });
  if (clearBtn) clearBtn.addEventListener('click', () => {
    if (!cart.length){ toast('Cart is already empty'); return; }
    if (confirm('Clear the cart?')) clearCart();
  });
  
  if (checkoutBtn) checkoutBtn.addEventListener('click', () => {
    if (!cart.length){ toast('Cart is empty'); return; }
    if (checkoutModal) checkoutModal.classList.remove('hidden');
  });
  if (closeModal) closeModal.addEventListener('click', () => { if (checkoutModal) checkoutModal.classList.add('hidden'); });

  /* ---------- Checkout handling (WhatsApp / Email) ---------- */
  if (checkoutForm){
    checkoutForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      if (!cart.length){ toast('Cart is empty'); return; }
      const fd = new FormData(checkoutForm);
      const name = (fd.get('name') || '').trim();
      const phone = (fd.get('phone') || '').trim();
      const email = (fd.get('email') || '').trim();
      const address = (fd.get('address') || '').trim();
      const city = (fd.get('city') || '').trim();
      const pincode = (fd.get('pincode') || '').trim();
      const delivery = fd.get('delivery') || 'standard';
      const payment = fd.get('payment') || 'cod';
      const notes = (fd.get('notes') || '').trim();

      if (!name || !phone || !address || !city || !pincode){
        toast('Please fill required fields');
        return;
      }

      const subtotal = cart.reduce((s,i)=> s + i.price * i.qty, 0);
      const expressFee = delivery === 'express' ? EXPRESS_FEE : 0;
      const shipping = subtotal > FREE_SHIPPING_THRESHOLD ? 0 : BASE_SHIPPING;
      const gst = Math.round(subtotal * GST_RATE);
      const grand = subtotal + shipping + gst + expressFee;

      // message for WhatsApp (human readable)
      let lines = cart.map((it, idx) => `${idx+1}. ${it.name} (${it.variant||'-'}) x${it.qty} — ${money(it.price*it.qty)}`).join('\n');
      let msgPlain = `Shopeasy Order\n\n${lines}\n\nSubtotal: ${money(subtotal)}\nShipping: ${money(shipping+expressFee)}\nGST (5%): ${money(gst)}\nGrand Total: ${money(grand)}\n\nCustomer:\nName: ${name}\nPhone: ${phone}\nEmail: ${email || '-'}\nAddress: ${address}, ${city} - ${pincode}\nDelivery: ${delivery}\nPayment: ${payment}\nNotes: ${notes || '-'}`;
      const waParam = encodeURIComponent(msgPlain);
      const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${waParam}`;

      window.open(waUrl, '_blank');
      toast('Opening WhatsApp…');
      // close things & clear cart if you want to
      if (checkoutModal) checkoutModal.classList.add('hidden');
      if (cartDrawer) { cartDrawer.classList.remove('open'); cartDrawer.setAttribute('aria-hidden','true'); }
      // optional: clear cart after placing (comment out if you don't want)
      // cart = []; saveCart(); renderCart();
    });
  }
  if (sendEmailBtn){
    sendEmailBtn.addEventListener('click', () => {
      if (!cart.length){ toast('Cart empty'); return; }
      const fd = new FormData(checkoutForm);
      const name = fd.get('name') || '';
      const phone = fd.get('phone') || '';
      const email = fd.get('email') || '';
      const address = fd.get('address') || '';
      const city = fd.get('city') || '';
      const pincode = fd.get('pincode') || '';
      const delivery = fd.get('delivery') || 'standard';
      const payment = fd.get('payment') || 'cod';
      const notes = fd.get('notes') || '';

      const subtotal = cart.reduce((s,i)=> s + i.price * i.qty, 0);
      const expressFee = delivery === 'express' ? EXPRESS_FEE : 0;
      const shipping = subtotal > FREE_SHIPPING_THRESHOLD ? 0 : BASE_SHIPPING;
      const gst = Math.round(subtotal * GST_RATE);
      const grand = subtotal + shipping + gst + expressFee;

      const lines = cart.map((it, idx) => `${idx+1}. ${it.name} (${it.variant||'-'}) x${it.qty} — ${money(it.price*it.qty)}`).join('\n');
      const body = `Shopeasy Order\n\n${lines}\n\nSubtotal: ${money(subtotal)}\nShipping: ${money(shipping+expressFee)}\nGST: ${money(gst)}\nGrand Total: ${money(grand)}\n\nCustomer:\n${name}\n${phone}\n${email}\n\nAddress:\n${address}, ${city} - ${pincode}\n\nDelivery: ${delivery}\nPayment: ${payment}\nNotes: ${notes}`;
      const mailto = `mailto:your-email@example.com?subject=${encodeURIComponent('Shopeasy Order')}&body=${encodeURIComponent(body)}`;
      window.location.href = mailto;
    });
  }

  /* ---------- Search & view all ---------- */
  if (searchInput){
    searchInput.addEventListener('input', (e) => {
      const q = String(e.target.value || '').trim().toLowerCase();
      if (!q) { renderDemoProducts(); return; }
      const filtered = DEMO_PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(q) || (p.variant && p.variant.toLowerCase().includes(q)) || (p.sku && p.sku.toLowerCase().includes(q))
      );
      renderDemoProducts(filtered);
    });
  }

  // View all button behavior: if user clears search input (or click again) it's just the list; we also provide a small "View All" helper
  function ensureViewAllBtn(){
    if (!productsGrid) return;
    if (document.getElementById('btnViewAll')) return;
    const btn = document.createElement('button');
    btn.id = 'btnViewAll';
    btn.className = 'btn';
    btn.textContent = 'View All';
    btn.style.margin = '8px 0';
    btn.addEventListener('click', () => { searchInput.value = ''; renderDemoProducts(); });
    const section = document.getElementById('products');
    if (section){
      const title = section.querySelector('.section-title');
      if (title) title.insertAdjacentElement('afterend', btn);
      else section.insertBefore(btn, section.firstChild);
    }
  }

  /* --------- Theme toggle (dark/light) -------- */
  if (themeToggle){
    themeToggle.addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      themeToggle.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
    });
  }
  
  /* ---------- Admin login flow & admin UI ---------- */
  if (userIcon){
    userIcon.addEventListener('click', () => {
      if (!userModal) return;
      // reset modal
      userModal.classList.remove('hidden');
      userNameInput.value = '';
      userPasswordInput.value = '';
      userPasswordInput.classList.add('hidden');
      modalTitle.textContent = 'Enter name';
      currentUser = null;
    });
  }
  if (closeUserModal){
    closeUserModal.addEventListener('click', () => {
      if (!userModal) return;
      userModal.classList.add('hidden');
    });
  }
  if (loginBtn){
    loginBtn.addEventListener('click', () => {
      const name = (userNameInput.value || '').trim();
      const pass = (userPasswordInput.value || '').trim();

      // step 1: name entry
      if (!currentUser && name){
        if (name === ADMIN_NAME){
          // ask for password
          modalTitle.textContent = 'Enter Password';
          userPasswordInput.classList.remove('hidden');
          currentUser = 'pending_admin';
          return;
        } else {
          // regular user
          currentUser = name;
          userIcon.textContent = name[0].toUpperCase();
          userModal.classList.add('hidden');
          toast(`Welcome, ${name}`);
          return;
        }
      }

      // step 2: admin password
      if (currentUser === 'pending_admin'){
        if (pass === ADMIN_PASS){
          adminMode = true;
          currentUser = ADMIN_NAME;
          userIcon.textContent = '👑';
          userModal.classList.add('hidden');
          toast('Admin mode enabled');
          enableAdminUI();
        } else {
          alert('Wrong password');
        }
        return;
      }

      alert('Please enter a name first');
    });
  }

  function enableAdminUI(){
    renderDemoProducts(); // adds per-card admin controls
    maybeShowAdminAddButton();
    // if detail open, show its admin info/controls
    if (currentProduct) showProductDetail(currentProduct);
  }

  /* ---------- Admin: Add / Edit Product Form (modal created by JS) ---------- */
  // create a reusable product form modal
  const productFormModal = document.createElement('div');
  productFormModal.className = 'modal hidden';
  productFormModal.id = 'productFormModal';
  productFormModal.innerHTML = `
    <div class="modal-panel">
      <div class="modal-head"><h3 id="pfTitle">Product Form</h3><button id="pfClose" class="close-btn">✖</button></div>
      <form id="productForm" class="product-form">
        <input type="hidden" name="id" />
        <div class="field"><label>Name</label><input name="name" required></div>
        <div class="field"><label>Price</label><input name="price" type="number" required></div>
        <div class="field"><label>Variant</label><input name="variant"></div>
        <div class="field"><label>Stock</label><input name="stock" type="number"></div>
        <div class="field"><label>Image URL</label><input name="img"></div>
        <div class="field"><label>SKU</label><input name="sku"></div>
        <div class="field"><label>HSN</label><input name="hsn"></div>
        <div class="field"><label>MRP</label><input name="mrp" type="number"></div>
        <div class="field"><label>Cost</label><input name="cost" type="number"></div>
        <div class="field"><label>Long description</label><textarea name="long" rows="3"></textarea></div>
        <div class="modal-actions">
          <button type="submit" class="btn primary">Save</button>
          <button type="button" id="pfCancel" class="btn">Cancel</button>
        </div>
      </form>
    </div>
  `;
  document.body.appendChild(productFormModal);

  const pfClose = document.getElementById('pfClose');
  const pfCancel = document.getElementById('pfCancel');
  const productForm = document.getElementById('productForm');
  const pfTitle = document.getElementById('pfTitle');

  function openProductForm(mode='add', product=null){
    if (!adminMode){ toast('Admin only'); return; }
    productFormModal.classList.remove('hidden');
    pfTitle.textContent = mode === 'add' ? 'Add Product' : 'Edit Product';
    // fill fields
    productForm.id.value = product ? product.id : '';
    productForm.name.value = product ? product.name : '';
    productForm.price.value = product ? product.price : '';
    productForm.variant.value = product ? product.variant : '';
    productForm.stock.value = product ? product.stock : 0;
    productForm.img.value = product ? (product.images && product.images[0] ? product.images[0] : product.img) : '';
    productForm.sku.value = product ? product.sku || '' : '';
    productForm.hsn.value = product ? product.hsn || '' : '';
    productForm.mrp.value = product ? product.mrp || '' : '';
    productForm.cost.value = product ? product.cost || '' : '';
    productForm.long.value = product ? product.long || '' : '';
  }
  if (pfClose) pfClose.addEventListener('click', () => productFormModal.classList.add('hidden'));
  if (pfCancel) pfCancel.addEventListener('click', () => productFormModal.classList.add('hidden'));

  productForm.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const fd = new FormData(productForm);
    const id = fd.get('id');
    const payload = {
      id: id || generateId(),
      name: (fd.get('name') || '').trim(),
      price: Number(fd.get('price') || 0),
      variant: (fd.get('variant') || '').trim(),
      stock: parseInt(fd.get('stock') || 0),
      img: (fd.get('img') || '').trim() || 'https://via.placeholder.com/300',
      sku: (fd.get('sku') || '').trim(),
      hsn: (fd.get('hsn') || '').trim(),
      mrp: Number(fd.get('mrp') || 0),to
      ,cost: Number(fd.get('cost') || 0),
      long: (fd.get('long') || '').trim(),
      images: [(fd.get('img') || '').trim() || 'https://via.placeholder.com/300'],
      bullets: []
    };

    if (id){
      // edit existing
      const idx = DEMO_PRODUCTS.findIndex(p => p.id === id);
      if (idx > -1){
        DEMO_PRODUCTS[idx] = Object.assign({}, DEMO_PRODUCTS[idx], payload);
        toast('Product updated');
      }
    } else {
      // add new
      DEMO_PRODUCTS.unshift(payload);
      toast('Product added');
    }
    productFormModal.classList.add('hidden');
    renderDemoProducts();
    renderCart(); // in case price or id changed on items in cart
  });

  function maybeShowAdminAddButton(){
    if (!adminMode) return;
    if (document.getElementById('btnAddProduct')) return;
    const section = document.getElementById('products');
    if (!section) return;
    const addBtn = document.createElement('button');
    addBtn.id = 'btnAddProduct';
    addBtn.className = 'btn primary';
    addBtn.textContent = '➕ Add Product';
    addBtn.style.margin = '8px 0';
    addBtn.addEventListener('click', () => openProductForm('add', null));
    const title = section.querySelector('.section-title');
    if (title) title.insertAdjacentElement('afterend', addBtn);
    else section.insertBefore(addBtn, section.firstChild);
  }
  /* ----------------- Init ------------------ */
  function init(){
    renderDemoProducts();
    renderCart();
    ensureViewAllBtn();
    // If admin mode externally set, enable UI
    if (adminMode) enableAdminUI();
    // Expose debug
    window._SE = {
      DEMO_PRODUCTS, cart, addToCart, renderDemoProducts, enableAdminUI, disableAdminUI: () => { adminMode=false; renderDemoProducts(); const b=document.getElementById('btnAddProduct'); if(b) b.remove(); }
    };
  }

  /* --------------- Helpers ----------------- */
  function escapeHtml(s){ return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  init();

})() ;
